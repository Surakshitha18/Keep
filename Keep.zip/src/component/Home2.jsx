import { Button } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom'

export default function Home2() {
  return (
    <div><Link to='/login'><Button >Admion Login</Button></Link></div>
  )
}
